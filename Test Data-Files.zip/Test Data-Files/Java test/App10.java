import java.util.*;
import java.io.*;

public class App10 {
    public static void main(String[] args) throws Exception {
        Properties props = new Properties();
        FileInputStream fis = new FileInputStream("config.properties");
        props.load(fis);
        fis.close();
        String user = props.getProperty("db.user");
        String pass = props.getProperty("db.pass");
        System.out.println("Connecting with " + user + " / " + pass);
    }
}
