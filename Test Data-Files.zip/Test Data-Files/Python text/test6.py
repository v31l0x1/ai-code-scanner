from flask import Flask, jsonify
import yaml 

app = Flask(__name__)

@app.route('/parse_config', methods=['POST'])
def parse_config():
    cfg = request.data.decode()
    data = yaml.load(cfg, Loader=yaml.Loader)
    return jsonify(data)
