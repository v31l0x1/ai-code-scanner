import java.sql.*;

public class App6 {
    public static void main(String[] args) throws Exception {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:test.db");
        String userInput = System.console().readLine();
        PreparedStatement ps = conn.prepareStatement("SELECT * FROM records WHERE id = ?");
        ps.setString(1, userInput);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) System.out.println(rs.getString("data"));
        conn.close();
    }
}
