import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class App9 extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String file = req.getParameter("file");
        File f = new File("/app/config/" + file);
        BufferedReader br = new BufferedReader(new FileReader(f));
        String line;
        while ((line = br.readLine()) != null) res.getWriter().println(line);
        br.close();
    }
}
