from flask import Flask, request, jsonify

app = Flask(__name__)
users = {"admin": "adminpass", "guest": "guestpass"}

@app.route('/delete_user', methods=['POST'])
def delete_user():
    username = request.form.get('username')
    if username:
        # No auth check: any user can delete any account
        return jsonify({"status": f"user {username} deleted"})
    return jsonify({"error": "username required"}), 400

@app.route('/login', methods=['POST'])
def login():
    u = request.form.get('username')
    p = request.form.get('password')
    if users.get(u) == p:
        return jsonify({"status": "logged in"})
    return jsonify({"error": "invalid credentials"})
