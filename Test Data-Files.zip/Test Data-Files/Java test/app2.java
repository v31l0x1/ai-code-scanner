import java.net.*;
import java.io.*;
import java.util.*;

public class App2 {
    public static void main(String[] args) throws Exception {
        ServerSocket server = new ServerSocket(9001);
        while (true) {
            Socket socket = server.accept();
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("GET")) {
                    File file = new File("/var/www/" + line.split(" ")[1]);
                    byte[] data = new byte[(int) file.length()];
                    new FileInputStream(file).read(data);
                    socket.getOutputStream().write(data);
                }
            }
        }
    }
}
