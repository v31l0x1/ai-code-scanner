from flask import Flask, send_file

app = Flask(__name__)

@app.route('/static/<path:filename>')
def serve_file(filename):
    return send_file(f'/var/www/html/{filename}')

