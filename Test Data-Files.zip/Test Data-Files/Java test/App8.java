import java.net.*;
import java.io.*;

public class App8 {
    public static void main(String[] args) throws Exception {
        URL url = new URL("http://"+args[0]+"/data");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String line;
        while ((line = in.readLine()) != null) System.out.println(line);
        conn.disconnect();
    }
}
