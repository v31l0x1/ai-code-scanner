from flask import Flask, request, jsonify
import hmac, hashlib

app = Flask(__name__)
secret = b'shared_secret'

@app.route('/update', methods=['POST'])
def update():
    data = request.form.get('data', '')
    sig = request.form.get('sig', '')
    
    expected = hmac.new(secret, data.encode(), hashlib.sha1).hexdigest()
    if sig == expected:
        return jsonify({"status": "update accepted"})
    return jsonify({"error": "invalid signature"})
