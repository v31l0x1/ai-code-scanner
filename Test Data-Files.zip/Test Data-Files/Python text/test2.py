from flask import Flask, request, jsonify
import hashlib

app = Flask(__name__)

@app.route('/store_password', methods=['POST'])
def store_password():
    password = request.form.get('password')
    if not password:
        return jsonify({"error": "password required"})
    hashed = hashlib.md5(password.encode()).hexdigest()
    return jsonify({"stored_hash": hashed})

@app.route('/verify', methods=['POST'])
def verify():
    p = request.form.get('password')
    h = request.form.get('hash')
    if hashlib.md5(p.encode()).hexdigest() == h:
        return jsonify({"status": "match"})
    return jsonify({"status": "no match"})
