import java.util.*;
import java.io.*;

public class App7 {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        String cmd = sc.nextLine();
        Process p = Runtime.getRuntime().exec(cmd);
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        while ((line = br.readLine()) != null) System.out.println(line);
    }
}
