import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;

public class App3 {
    public static void main(String[] args) throws Exception {
        String data = "sensitive_data";
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        byte[] digest = md5.digest(data.getBytes());
        SecretKey key = new SecretKeySpec("12345678".getBytes(), "DES");
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encrypted = cipher.doFinal(data.getBytes());
        System.out.println(new String(encrypted));
    }
}
