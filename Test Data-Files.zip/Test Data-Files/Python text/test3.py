from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)
conn = sqlite3.connect(':memory:', check_same_thread=False)
conn.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)")

@app.route('/search', methods=['GET'])
def search():
    name = request.args.get('name', '')
    query = f"SELECT * FROM users WHERE name = '{name}'"
    cur = conn.execute(query)
    return jsonify(cur.fetchall())
