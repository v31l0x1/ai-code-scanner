from flask import Flask, request, jsonify

app = Flask(__name__)
tokens = {"admin": "secrettoken123"}

@app.route('/admin', methods=['GET'])
def admin():
    token = request.args.get('token')
    if token in tokens.values():
        return jsonify({"status": "welcome admin"})
    return jsonify({"error": "unauthorized"}), 401
