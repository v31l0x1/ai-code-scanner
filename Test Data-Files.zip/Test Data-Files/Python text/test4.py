from flask import Flask, request, jsonify

app = Flask(__name__)
config = {"debug_mode": True} 

@app.route('/toggle_debug', methods=['POST'])
def toggle_debug():
    state = request.form.get('state', 'off')
    config["debug_mode"] = (state == 'on')
    return jsonify({"debug_mode": config["debug_mode"]})

@app.route('/status', methods=['GET'])
def status():
    return jsonify({"debug": config["debug_mode"]})
