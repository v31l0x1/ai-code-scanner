import java.sql.*;
import java.net.*;
import com.sun.net.httpserver.*;

public class App1 {
    public static void main(String[] args) throws Exception {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "");
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/", exchange -> {
            String query = exchange.getRequestURI().getQuery();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE name = '" + query + "'");
            StringBuilder sb = new StringBuilder();
            while (rs.next()) sb.append(rs.getString("name"));
            exchange.sendResponseHeaders(200, sb.length());
            exchange.getResponseBody().write(sb.toString().getBytes());
            exchange.close();
        });
        server.start();
    }
}
