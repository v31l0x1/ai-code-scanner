import java.io.*;
import java.net.*;

public class App4 {
    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(8081);
        Socket s = ss.accept();
        BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
        String filename = br.readLine();
        FileOutputStream fos = new FileOutputStream("/tmp/uploads/" + filename);
        int ch;
        while ((ch = br.read()) != -1) fos.write(ch);
        fos.close();
        s.close();
    }
}
