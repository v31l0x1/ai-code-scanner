from flask import Flask, request

app = Flask(__name__)
logs = []

@app.route('/login', methods=['POST'])
def login():
    user = request.form.get('username')
    
    if user == "admin" and request.form.get('password') == "password":
        logs.append(f"Login success for {user}")
        return "welcome"
    return "fail"

@app.route('/logs', methods=['GET'])
def get_logs():
    return "<br>".join(logs)
